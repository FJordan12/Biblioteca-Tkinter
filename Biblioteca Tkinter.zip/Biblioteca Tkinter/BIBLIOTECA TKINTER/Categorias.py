class Categoria:
    def _init_(self, nombre):
        self.__nombre = nombre

    def get_nombre(self):
        return self.__nombre

    def set_nombre(self, nombre):
        self.__nombre = nombre

    def mostrar_info(Self):
        print("nombre: ", Self.__nombre)